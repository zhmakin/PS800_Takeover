/*
 * battery.c
 *
 *  Created on: Jun 15, 2023
 *      Author: azh19
 */
#include "battery.h"

struct battery li_fe_po;

