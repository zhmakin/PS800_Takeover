/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "comp.h"
#include "dac.h"
#include "dma.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "controller.h"
#include "battery.h"
#include <stm32g4xx_hal_rcc.h>
#include "stm32g4xx_hal.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
	__IO ITStatus RX_Ready = RESET;

	uint32_t _150us, _10ms, _1s;

	uint32_t POOL, MEASURES, WORK, POWER_REQUEST;

	double UINf;
	double UBATf;
	double IBATf;
	double IPVf;
	double IOUTf;
	double DCf;

	int16_t UINi;
	int16_t UBATi;
	int16_t IBATi;
	int16_t IINi;
	int16_t IOUT;
	uint16_t mode;

	txbuf UTX;

	rxbuf URX;

	PIcontroller PIC;

	struct pv pv400;
	struct battery lifepo20;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_ADC2_Init();
  MX_COMP1_Init();
  MX_COMP2_Init();
  MX_SPI1_Init();
  MX_TIM8_Init();
  MX_DAC1_Init();
  MX_DAC3_Init();
  MX_TIM1_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */
  Init();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  /************ SCHEDULER 150US ************/
	  if(_150us == 0){

		  _150us = TIMER_150US;

		  compute_loop_measures();

		  /* Control loops */
		  if(mode == MODE_CHARGE){

			  __HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_3,PWM_PERIOD * PIcontroller_Buck(&PIC, UINf, UBATf, IBATf));

		  }else
			  if(mode == MODE_DISCHARGE){

				  __HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_3,PWM_PERIOD * PIcontroller_Boost(&PIC, UBATf, UINf, 0));

			  }
	  }

	  /************ SCHEDULER 10mS ************/
	  if(_10ms == 0){

		  _10ms = TIMER_10mS;

		  /* Work mode manager */
		  if(WORK){

			  WorkManager();
		  }

		  /* Send measures data to USART port */
		  if(MEASURES){

			  MEASURES = 0;
			  send_measures();
		  }
	  }

	  /************ SCHEDULER 1S ************/
	  if(_1s ==0){

		  _1s = TIMER_1S;

		  if(POOL){

			  send_measures();

		  };
	  }

	  /************ USART RX Task ************/
	  if (RX_Ready){

		  RX_Ready = RESET;

		  /* USART Receive message decode */
		  USART_Decode(&URX);

		  /* Get UART ready to receive */
		  USART_RX_DMA_Prepare();

	  }

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV2;
  RCC_OscInitStruct.PLL.PLLN = 16;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

void Init(void){

	/* ADC initial calibration */
	HAL_ADCEx_Calibration_Start(&hadc1, ADC_SINGLE_ENDED );
	HAL_ADCEx_Calibration_Start(&hadc2, ADC_SINGLE_ENDED );

	/* PWM timers activation */
	HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_3);
	HAL_TIMEx_PWMN_Start(&htim1,TIM_CHANNEL_3);

	/* PI controller initialization */
	PIcontroller_Init(&PIC);

	/* Time-State machine initialization */
	_1s = 		TIMER_1S;
	_10ms = 	TIMER_10mS;
	_150us = 	TIMER_150US;

	POOL = 		NO;
	MEASURES = 	NO;
	WORK = 		NO;
	POWER_REQUEST = NO;
	mode = 0;

	init_idle();

	/* Put USART in a "Ready to receive" mode */
	USART_RX_DMA_Prepare();

	/* Average measurement routines initialization */
	initializeMovingAverage(&uin_average);
	initializeMovingAverage(&iin_average);
	initializeMovingAverage(&ubat_average);
	initializeMovingAverage(&ibat_average);

	/* Solar panel initialization */
	pv400.max_current = 12;
	pv400.max_power_voltage = 21.5;//32.5;
	pv400.tracking_voltage = pv400.max_power_voltage - 1.5;

	/* Battery initialization */
	lifepo20.settings.capacity = 20000;
	lifepo20.settings.max_charge_current = 0.5;//10;
	lifepo20.settings.min_charge_current = 0.1;//1;
	lifepo20.settings.v_charge = 14.4;//29;
	lifepo20.settings.v_empty = 10;//20;
	lifepo20.settings.v_full = 12.2;//26.4;
}

void PIcontroller_Init(PIcontroller *pic){

	/* Controller initialization*/
	pic->t = 0.00015;

	pic->Kp1 = 0.29;
	pic->Ki1 = 130;//130;
	pic->K1 = pic->Ki1 * pic->t *0.5;

	pic->Kp2 = 1;
	pic->Ki2 = 300;//30;
	pic->K2 = pic->Ki2 * pic->t *0.5;

	pic->Kp3 = 0.1;
	pic->Ki3 = 35;
	pic->K3 = pic->Ki1 * pic->t *0.5;

	pic->error_1 = 0;
	pic->prop_1 = 0;
	pic->int_1 = 0;
	pic->int_1_sat = 0;
	pic->lastError_1 = 0;
	pic->pi_1 = 0;
	pic->pi_1_sat = 0;

	pic->error_2 = 0;
	pic->prop_2 = 0;
	pic->int_2 = 0;
	pic->int_2_sat = 0;
	pic->lastError_2 = 0;
	pic->pi_2 = 0;
	pic->dc = 0;

	pic->error_3 = 0;
	pic->prop_3 = 0;
	pic->int_3 = 0;
	pic->lastError_3 = 0;

	pic->limMin_DC = 0.05;
	pic->limMax_DC = 0.95;
}

void WorkManager(void){

	if(POWER_REQUEST){

		if(UBATf > lifepo20.settings.v_empty){

			/* Go to discharge mode */
			init_discharge();

			if((IOUTf - IPVf) > 0){

				/* Set top switch to PWM mode */
				TIM1_PWM_Ch3_Pin_Init();
			}
			else{
				/* Set top switch to inactive mode */
				TIM1_PWM_Ch3_Pin_DeInit(GPIO_PIN_RESET);
			}
			/* Set boost voltage to predefined value */
			PIC.u_setpoint = pv400.tracking_voltage;

		}
		else{
			/* Exit discharge mode, go in IDLE */
			init_idle();
		}
	}
	else{
		if(UINf > (UBATf + 0.2)){

			if(UBATf < lifepo20.settings.v_full){

				/* Go to Charge mode */
				init_charge();

				/* Set setpoints */
				PIC.u_setpoint = lifepo20.settings.v_charge;
				PIC.i_setpoint = lifepo20.settings.max_charge_current;
			}
			else{

				if(UBATf > lifepo20.settings.v_stop_charge){

					if(IBATf > lifepo20.settings.min_charge_current){

						/* Stop charge, go IDLE mode */
						init_idle();
					}
				}
			}
		}
		else{
			/* Stop charge, go IDLE mode */
			init_idle();
		}
	}
}


void Timer8Update_Callback(void){

	/* SCHEDULER 100uS */
	if(_150us){

		_150us--;

	}

	/* SCHEDULER 10mS */
	if(_10ms) {

		_10ms--;

	}

	/* SCHEDULER 1S */
	if(_1s){

		_1s--;
	}
}

void Timer1Update_Callback(void){

}

void USART_RX_DMA_Prepare(void){

	if (HAL_UART_Receive_DMA(&huart1, (uint8_t *)&URX.Rx[0], RXBUFFERSIZE) != HAL_OK)
	{
		Error_Handler();
	}
}

void USART_Decode(rxbuf *rx){

	  switch(URX.data.MODE){

	  case MODE_IDLE:
		  send_confirmation();
		  WORK = NO;
		  init_idle();
		  break;

	  case MODE_POOL:
			if(POOL) POOL = NO;
			else POOL = YES;
		  break;

	  case MODE_SINGLE_MEAS:
		  MEASURES = YES;
		  break;

	  case MODE_WORK:
		  send_confirmation();
		  if(URX.Rx[2] == 0x01) POWER_REQUEST = YES;
		  else POWER_REQUEST = NO;
		  WORK = YES;
		  break;

	  default: break;
	  }
}

void compute_loop_measures(void){

	UINf = GET_Real_Vpv();
	UBATf = GET_Real_Vbat();
	IBATf = GET_Real_Ibat();
	IPVf = GET_Real_Ipv();
	IOUTf = GET_Real_Iout();

	UINi = updateMovingAverage(&uin_average,(uint16_t)(UINf * M_DENOM));
	UBATi = updateMovingAverage(&iin_average,(uint16_t)(UBATf * M_DENOM));
	IINi = updateMovingAverage(&ubat_average,(uint16_t)(IPVf * M_DENOM));
	IBATi = updateMovingAverage(&ibat_average,(uint16_t)(IBATf * M_DENOM));

	/** Start ADC-DMA conversion cycle **/
	HAL_ADC_Start_DMA(&hadc1, (uint32_t*)&ADC_Read_Buffer[0], 3);
	HAL_ADC_Start_DMA(&hadc2, (uint32_t*)&ADC_Read_Buffer[3], 2);
}


void init_idle(void){

	mode = MODE_IDLE;
	TIM1_PWM_Ch3_Pin_DeInit(GPIO_PIN_RESET);
	__HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_3, 0);
	HAL_TIMEx_PWMN_Stop(&htim1,TIM_CHANNEL_3);

}


void init_charge(void){

	mode = MODE_CHARGE;
	HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_3);
	HAL_TIMEx_PWMN_Start(&htim1,TIM_CHANNEL_3);
	TIM1_PWM_Ch3_Pin_Init();
}

void init_discharge(void){

	mode = MODE_DISCHARGE;
	HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_3);
	HAL_TIMEx_PWMN_Start(&htim1,TIM_CHANNEL_3);
}


void send_measures(void){

	UTX.data.cmd = mode;
	UTX.data.loop[0] = UINi;
	UTX.data.loop[1] = UBATi;
	UTX.data.loop[2] = IBATi;
	UTX.data.loop[3] = (int16_t)(PIC.dc * 100);
	UTX.data.loop[4] = IINi;
	UTX.data.loop[5] = (uint16_t)(UINi * IINi / M_DENOM);
	UTX.data.loop[6] = (uint16_t)(UBATi * IBATi / M_DENOM);
	UTX.data.loop[7] = (int16_t)(PIC.error_1 * 100);
	UTX.data.loop[8] = (int16_t)(PIC.prop_1 * 100);
	UTX.data.loop[9] = (int16_t)(PIC.int_1 * 100);
	UTX.data.loop[10] = (int16_t)(PIC.pi_1_sat * 100);
	UTX.data.loop[11] = (int16_t)(PIC.error_2 * 100);
	UTX.data.loop[12] = (int16_t)(PIC.prop_2 * 100);
	UTX.data.loop[13] = (int16_t)(PIC.pi_2 * 100);

	UTX.Tx[TXBUFFERSIZE - 1] = crc8_checksum(&UTX.Tx[0] , TXBUFFERSIZE - 1);

	if (HAL_UART_Transmit_DMA(&huart1, (uint8_t*)&UTX.Tx[0], TXBUFFERSIZE) == HAL_ERROR)
	{
		Error_Handler();
	}

}

void send_confirmation(void){
	
	if (HAL_UART_Transmit_DMA(&huart1, (uint8_t*)&URX.Rx[0], RXBUFFERSIZE) == HAL_ERROR)
	{
		Error_Handler();
	}
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *UartHandle)
{
  if(crc8_checksum(&URX.Rx[0], RXBUFFERSIZE) == CRC_OK){

	  RX_Ready = SET;

  }
  else return;
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
