/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    controller.c
  * @brief   This file provides PI controller routines.
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "controller.h"
#include "main.h"

extern txbuf UTX;

void PIcontroller_Setpoints_Init(PIcontroller *pic, double u_setpoint, double i_setpoint){
	pic->iMax = i_setpoint;
	pic->limMax_u = u_setpoint;

	pic->i_setpoint = i_setpoint;
	pic->u_setpoint = u_setpoint;
}


double PIcontroller_Buck(PIcontroller *pic, double u_in, double u_out, double i_ind){

	/*******U LOOP*******/
	/* feedback loop error */
	pic->error_1 = pic->u_setpoint - u_out;

	/* Proportional */
	pic->prop_1 = pic->error_1 * pic->Kp1;

	/* Integrational */
	pic->int_1 = pic->int_1_sat + (pic->error_1 + pic->lastError_1) * pic->K1;

	/* Anti-windup*/
	double MinLimit, MaxLimit;

	/* Integrator limits */
	if(pic->i_setpoint > pic->prop_1){

		MaxLimit = pic->i_setpoint - pic->prop_1;
	}
	else{
		MaxLimit = 0.0f;
	}

	if(0 < pic->prop_1){

		MinLimit = -pic->prop_1;
	}
	else{
		MinLimit = 0.0f;
	}

	/* Clamping */
	pic->int_1_sat = pic->int_1;
	if (pic->int_1_sat > MaxLimit){

		pic->int_1_sat = MaxLimit;

	} else if (pic->int_1_sat < MinLimit){

		pic->int_1_sat = MinLimit;

	}

	/* Memorize error value */
	pic->lastError_1 = pic->error_1;
	MinLimit = MaxLimit = 0;

	/* Compute I-loop output */
	pic->pi_1_sat = pic->pi_1 = pic->prop_1 + pic->int_1_sat;

	if(pic->pi_1 > pic->i_setpoint)
		pic->pi_1_sat = pic->i_setpoint;
	else
		if (pic->pi_1 < 0)
			pic->pi_1_sat = 0;

	pic->error_2 = pic->pi_1_sat - i_ind;

	/* Memorize error value */
	pic->lastError_2 = pic->error_2;

	/*******U LOOP*******/
	/* Proportional */
	pic->prop_2 = pic->error_2 * pic->Kp2;

	/* Integrational */
	pic->int_2 = pic->int_2_sat + (pic->error_2 + pic->lastError_2) * pic->K2;

	/* Anti-windup*/
	/* Integrator limits */
	if(pic->u_setpoint > pic->prop_2){

		MaxLimit = pic->u_setpoint - pic->prop_2;
	}
	else{
		MaxLimit = 0.0f;
	}

	if(0 < pic->prop_2){

		MinLimit = -pic->prop_2;
	}
	else{
		MinLimit = 0.0f;
	}

	/* Clamping */
	pic->int_2_sat = pic->int_2;
	if (pic->int_2_sat > MaxLimit){

		pic->int_2_sat = MaxLimit;

	} else if (pic->int_2_sat < MinLimit){

		pic->int_2_sat = MinLimit;

	}

	MinLimit = MaxLimit = 0;

	/* Duty cycle computing */
	pic->dc = (pic->prop_2 + pic->int_2_sat + u_out) / u_in;

	/* DC conditioning */

	if(pic->dc > pic->limMax_DC){

		pic->dc = pic->limMax_DC;

	}else if(pic->dc < pic->limMin_DC){

		pic->dc = pic->limMin_DC;

	}

	return pic->dc;
}

double PIcontroller_Boost(PIcontroller *pic, double u_in, double u_out, double i_ind){

	pic->error_3 = 1 - u_out / pic->u_setpoint;

	/* Proportional */
	pic->prop_3 = pic->error_3 * pic->Kp1;

	/* Integrational */
	pic->int_3 = pic->int_3 + (pic->error_3 + pic->lastError_3) * pic->K3;

	/* Memorize error value */
	pic->lastError_3 = pic->error_3;

	/* Compute U-loop output */
	/* Duty cycle computing */
	pic->dc = 1 - (pic->prop_3 + pic->int_3);

	/* DC conditioning */

	if(pic->dc > pic->limMax_DC){

		pic->dc = pic->limMax_DC;

	}else if(pic->dc < pic->limMin_DC){

		pic->dc = pic->limMin_DC;

	}

	return pic->dc;
}

