/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g4xx_hal.h"
#include "controller.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */
extern uint32_t _100us;
typedef union {
	uint8_t Tx[33];
	__packed struct{
		uint16_t cmd;
		int16_t loop[15];
		uint8_t crc;
	} data;
} txbuf;

typedef union {
	uint8_t Rx[16];
	__packed struct{
		uint16_t MODE;
		uint16_t UOUT;
		uint16_t IOUT;
	} data;
} rxbuf;

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */
void USART_RX_DMA_Prepare(void);
void USART_Decode(rxbuf *rx);
void Init(void);
void PIcontroller_Init(PIcontroller *pic);
void compute_loop_measures(void);
void WorkManager(void);
void init_idle(void);
void init_charge(void);
void init_discharge(void);
void send_measures(void);
void send_confirmation(void);
void Timer8Update_Callback(void);
void Timer1Update_Callback(void);
uint8_t get_crc(uint8_t *buf, uint8_t len);
extern TIM_HandleTypeDef htim1;
/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/

/* USER CODE BEGIN Private defines */
#define TIMER_150US 		10
#define TIMER_10mS 			667
#define TIMER_1S 			66667

#define PWM_PERIOD			480

#define RXBUFFERSIZE 		7
#define TXBUFFERSIZE 		33
#define CRC_OK				0

#define MODE_IDLE 			0xAA00
#define MODE_CHARGE 		0xAA01
#define MODE_DISCHARGE 		0xAA02
#define MODE_POOL 			0xAA03
#define MODE_SINGLE_MEAS 	0xAA04
#define MODE_WORK		 	0xAA05

#define NO					0
#define YES					1

#define M_DENOM				(double)100

#define UININD 				0
#define UBATIND 			1
#define IBATIND 			2
#define DCIND 				3
#define IININD 				4
#define P_PV_IND			5
#define P_CH_IND			6
#define ERROR1_IND			7
#define P1_IND				8
#define I1_IND				9
#define PI_SAT_IND			10
#define ERROR2_IND			11
#define P2_IND				12
#define I2_IND				13


/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
