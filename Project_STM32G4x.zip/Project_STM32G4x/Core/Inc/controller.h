#ifndef PI_CONTROLLER_H
#define PI_CONTROLLER_H

typedef struct {

	/*Coefficients*/
	double Kp1;
	double Ki1;
	double K1;

	double Kp2;
	double Ki2;
	double K2;

	double Kp3;
	double Ki3;
	double K3;

	/*Limit*/
	double limMax_u;
	double limMin_u;
	double iMax;
	double iMin;
	double limMin_DC;
	double limMax_DC;
	double u_setpoint;
	double i_setpoint;
	double p_setpoint;

	/*Sample time*/
	double t;

	/*variables*/
	double error_1;
	double lastError_1;

	double prop_1;
	double int_1;
	double int_1_sat;

	double pi_1;
	double pi_1_sat;

	double error_2;
	double lastError_2;
	double prop_2;
	double int_2;
	double int_2_sat;
	double pi_2;
	double dc;

	double error_3;
	double lastError_3;
	double prop_3;
	double int_3;

} PIcontroller;

void PIcontroller_Setpoints_Init(PIcontroller *pic, double u_setpoint, double i_setpoint);
double PIcontroller_Buck(PIcontroller *pic, double u_in, double u_out, double i_ind);
double PIcontroller_Boost(PIcontroller *pic, double u_in, double u_out, double i_ind);


#endif
