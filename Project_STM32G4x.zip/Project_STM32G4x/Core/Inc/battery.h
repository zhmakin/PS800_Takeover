/*
 * battery.h
 *
 *  Created on: Jun 15, 2023
 *      Author: azh19
 */

#ifndef INC_BATTERY_H_
#define INC_BATTERY_H_
#include "stm32g4xx_hal.h"

struct battery{
	uint16_t available;
	uint32_t time;
	int16_t temperature;
	double voltage;
	double current;

	struct{
		double v_empty;
		double v_full;
		double v_charge;
		double v_stop_charge;
		double max_charge_current;
		double min_charge_current;
		uint16_t capacity;
		int16_t temp_low;
		uint16_t temp_high;
		uint16_t alarm_timer;
		uint16_t stop_charge_time;
	} settings;

	struct{
		unsigned int charged : 1;
		unsigned int discharged : 1;
		unsigned int charging : 1;
		unsigned int discharging : 1;
		unsigned int overheaated : 1;
		unsigned int overvoltage : 1;
		unsigned int undervoltage : 1;
	}state;

};

struct pv{
	double max_power_voltage;
	double max_current;
	double tracking_voltage;
};

#endif /* INC_BATTERY_H_ */
